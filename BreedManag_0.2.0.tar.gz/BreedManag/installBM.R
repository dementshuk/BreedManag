installBM<- function() {

  install.packages("shiny")
  install.packages("readxl")
  install.packages("pedigreemm")
  install.packages("DT")
  install.packages("plyr")
  install.packages("reshape2")
  install.packages("readxl")

}
